from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='auto_explore',
            executable='explorer_node',
            name='explorer_node',
            output='screen'
        )
    ])

