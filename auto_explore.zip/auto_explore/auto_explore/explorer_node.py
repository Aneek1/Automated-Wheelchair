import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from nav2_msgs.action._navigate_to_pose import NavigateToPose_Result
from nav2_msgs.action._navigate_to_pose import NavigateToPose_FeedbackMessage
from nav_msgs.msg import OccupancyGrid
from nav2_msgs.action import NavigateToPose
from action_msgs.msg import GoalStatus


import numpy as np
import cv2

class FrontierExplorer(Node):
    def __init__(self):
        super().__init__('explorer_node')
        self.get_logger().info("🚀 Frontier Explorer Node Started!")

        self.map_sub = self.create_subscription(
            OccupancyGrid,
            '/map',
            self.map_callback,
            10
        )
        self.client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.map = None
        self.map_info = None

        self.goal_in_progress = False
        self.goal_reached = False
        self.confirm_timer = None

        self.last_goal_point = None

    def map_callback(self, msg):
        self.map = np.array(msg.data).reshape((msg.info.height, msg.info.width)).astype(np.int8)
        self.map_info = msg.info

        if not self.goal_in_progress and not self.goal_reached:
            self.explore()

    def explore(self):
        if self.map is None:
            return

        frontiers = self.find_frontiers(self.map)
        if not frontiers:
            self.get_logger().info("✅ 没有可探索区域，建图完成。")
            return

        for target in frontiers:
            if self.last_goal_point is not None:
                dist = np.hypot(target[0] - self.last_goal_point[0],
                                target[1] - self.last_goal_point[1])
                if dist < 0.5:
                    self.get_logger().info(f"⚠️ 跳过与上一个目标过近的点: ({target[0]:.2f}, {target[1]:.2f})")
                    continue  # 尝试下一个点
            # 找到合适的新目标
            self.send_goal(target)
            self.last_goal_point = target
            return

        self.get_logger().info("✅ 没有可用的新frontiers（太近），暂停探索。")


    def find_frontiers(self, map_data):
        mask_unknown = (map_data == -1).astype(np.uint8)
        mask_free = (map_data == 0).astype(np.uint8)

        dilated = cv2.dilate(mask_free, np.ones((3, 3), np.uint8))
        frontier = cv2.bitwise_and(dilated, mask_unknown)

        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(frontier)
        frontiers = []
        for i in range(1, num_labels):
            if stats[i, cv2.CC_STAT_AREA] < 20:
                continue
            cx, cy = map(int, centroids[i])
            world_x = self.map_info.origin.position.x + cx * self.map_info.resolution
            world_y = self.map_info.origin.position.y + cy * self.map_info.resolution
            frontiers.append((world_x, world_y))

        return frontiers

    def send_goal(self, point):
        if not self.client.wait_for_server(timeout_sec=2.0):
            self.get_logger().warn("❌ 导航服务器不可用")
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = point[0]
        goal_msg.pose.pose.position.y = point[1]
        goal_msg.pose.pose.orientation.w = 1.0

        self.goal_in_progress = True
        self.goal_reached = False
        self.current_target = point  # 保存当前目标点用于 future 判断

        self.get_logger().info(f"🚀 正在导航至 frontier: ({point[0]:.2f}, {point[1]:.2f})")

        self.send_goal_future = self.client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback
        )
        self.send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn("❌ 目标被拒绝")
            self.goal_in_progress = False
            return

        self.get_logger().info("✅ 目标已接受，等待完成")
        self.goal_handle = goal_handle
        goal_handle.get_result_async().add_done_callback(self.result_callback)

    def feedback_callback(self, feedback_msg):
        current_pose = feedback_msg.feedback.current_pose.pose.position
        self.get_logger().debug(f"📍 当前导航位置: x={current_pose.x:.2f}, y={current_pose.y:.2f}")

    def result_callback(self, future):
        result = future.result()
        status = result.status

        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info("🎯 导航成功，2秒后继续探索")
            self.goal_in_progress = False
            self.goal_reached = True
            self.confirm_timer = self.create_timer(2.0, self.confirm_callback)
        else:
            self.get_logger().warn(f"❌ 导航失败（状态码: {status}），尝试下一个目标")
            self.goal_in_progress = False
            self.goal_reached = False
            self.explore()

    def confirm_callback(self):
        self.get_logger().info("⏱️ 2秒确认完成，开始下一个目标")
        self.goal_reached = False
        self.confirm_timer.cancel()
        self.explore()

def main(args=None):
    rclpy.init(args=args)
    node = FrontierExplorer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

