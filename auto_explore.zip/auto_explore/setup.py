from setuptools import setup

package_name = 'auto_explore'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/' + package_name, ['package.xml']), 
        ('share/' + package_name + '/launch', ['launch/explore_launch.py']),
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='sutd',
    maintainer_email='sutd@example.com',
    description='Simple frontier exploration node for TurtleBot3 + SLAM',
    license='MIT',
    entry_points={
        'console_scripts': [
            'explorer_node = auto_explore.explorer_node:main',
        ],
    },
)

